 #!/bin/sh
free -m | awk 'NR==2{printf "Free memory space: %.fMB\tIn percentage:%.2f%%\t\t \n", $4, $4*100/$2}' 
df -h | awk '$NF=="/"{printf "Disk Usage: %d/%dGB (%s)\n", $3,$2,$5}'
top -bn1 | grep load | awk '{printf "CPU Load: %.2f\n", $(NF-2)}'

