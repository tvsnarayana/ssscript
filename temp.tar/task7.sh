#!/bin/sh
tar -cvf temp.tar .
git init
git commit --amend --reset-author 
git add temp.tar
git commit -m "first commit"
git remote add origin https://github.com/tvsnarayana/temp.git
git push https://tvsnarayana:Venkat_143@github.com/tvsnarayana/temp.git
rm -f temp.tar
wget https://github.com/tvsnarayana/temp/temp.tar
cd temp
tar -xvzf temp.tar
rm -f temp.tar
echo "Changing file group to apache" >> $fname
sudo chown -R apache /home/U86512/trial/*

echo "Creating symlink from /home/U86512/public_html to /home/U86512/www/html/" >> $fname
ln -s /home/U86512/public_html /home/U86512/www/html/


service httpd start
portnum=$(sudo netstat -6tnlp | grep httpd |  awk ' {print $4}' | sed 's/^...//')

if ! [ -z "$portnum" ]
then
   pid=$(ps -ef | grep apache |  awk ' { print $2 } '| head -n 1)

   echo "Httpd Service started" >> $fname
   echo "Apache process id is $pid " >> $fname
else
echo "$portnum"
fi


