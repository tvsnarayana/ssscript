#!/bin/sh
PARTITION=`df -h | awk '$NF=="/"{gsub("%",""); printf $5}'`
if [ $PARTITION -ge 25 ]; then
   printf 'Memory exceeds 25%%'
fi
LOAD=`top -bn1 | grep load | awk '{printf "%.2f\n", $(NF-2)}'`
if [$LOAD -ge 60]; then
   printf 'CPU Load Reached 60%%'
fi
